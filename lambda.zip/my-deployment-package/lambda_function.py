import mysql.connector
import json
import boto3


# Set up the connection to the read database
read_db=mysql.connector.connect(
    host="twinder-mysql-db.ccqhkjzj3mlw.us-west-2.rds.amazonaws.com",
    user="db_user",
    password="db_xxxx",
    database="swipeInfoDB"
)

#Matches Table:user_id, match_list, match_count
#Stats Table:user_id, likes, dislikes

def lambda_handler(event, context):
    for record in event['Records']:
        operation = record['eventName']
        if operation == 'INSERT':
            new_image = record['dynamodb']['Keys']
            # Extract the necessary fields from the record data
            swipe_info = new_image['swipe_info']['S']
            components = swipe_info.split('#')
            swiper = components[0]
            swipee = components[1]
            direction = components[2]
            cursor = read_db.cursor() 
            getStatsSQL = "SELECT likes from Stats WHERE user_id = %s;"
            cursor.execute(getStatsSQL, (swipee,))
            result_set = cursor.fetchall()
            if len(result_set) == 0:
                insertStatsSQL = "INSERT INTO Stats (user_id, likes, dislikes) values (%s, 0, 0);"
                cursor.execute(insertStatsSQL, (swipee,))
            getMatchCountSQL = "SELECT match_count from Matches where user_id = %s;"
            cursor.execute(getMatchCountSQL, (swipee,))
            result_set = cursor.fetchall()
            number_matches = 0
            if len(result_set) == 0:
                insertMatchesSQL="INSERT INTO Matches (user_id, match_list, match_count) values (%s, '', 0);"
                cursor.execute(insertMatchesSQL, (swipee,))
            else:
                number_matches = result_set[0][0]
            read_db.commit()
            updateMatchesSQL=''
            updateStatsSQL=''
            if direction == 'right':
                if number_matches == 0:
                    updateMatchesSQL = "UPDATE Matches SET match_list = %s, match_count = 1 WHERE user_id = %s;"
                if number_matches < 100 and number_matches != 0:
                    updateMatchesSQL = "UPDATE Matches SET match_list = CONCAT(match_list,',',%s), match_count = match_count + 1 WHERE user_id = %s;"
                updateStatsSQL = "UPDATE Stats SET likes = likes + 1 WHERE user_id = %s;"
            else:
                updateStatsSQL = "UPDATE Stats SET dislikes = dislikes + 1 WHERE user_id = %s;"
            stats_values = (swipee,)
            cursor.execute(updateStatsSQL, stats_values)
            matches_values = (swiper, swipee)
            cursor.execute(updateMatchesSQL, matches_values)
            read_db.commit()
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Read database updated'})
    }

